Conceptos básicos

    1. Averigua cuál es el intérprete de comandos por defecto en tu sistema.
    2. Lanza sh desde el terminal, comprueba que realmente se está ejecutando  y regresa al IC original.
    3. Guarda los nombres de las entradas (contenido) del directorio /etc en el fichero de nombre file-tmp.
    4. Añade al fichero del punto anterior los nombres de las entradas (contenido) del directorio /bin.
    5. En una sola instrucción, guarda los nombres de las entradas (contenido) de los directorios /etc y /usr en el fichero file-tmp.
