#!/bin/sh

if [ -f $1 ]
then
	echo "Si existe el fichero"
else
	echo "No existe tal fichero"
fi
