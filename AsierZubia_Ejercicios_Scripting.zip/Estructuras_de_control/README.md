Estructuras de control

  1. Programa un script que compruebe que recibe dos parámetros.
  2. Programa un script que recibe como parámetro dos números e indica cuál es el de mayor valor.
  3. Programa un script que compruebe que el fichero que recibe como parámetro existe.
  4. Programa un script que muestre sólo los nombres de los ficheros del directorio principal, es decir, sin la parte correspondiente al directorio en el que están. Ejemplo: /home/user/file1.txt => file1.txt
  5. Programa un script que comprueba que el directorio que recibe como parámetro existe y después cuenta cuántos subdirectorios y cuántos ficheros contiene.
  6. Como en el caso anterior, pero contando el número de ficheros con extensión txt.
  7. Programa un script que calcula y muestra la suma de los números que recibe como parámetro. El número de parámetros no se conoce a priori.
