#!/bin/sh

if [ $# -eq 2 ]
then
	echo Se han recibido dos parametros
else
	echo No se han recibido dos parametros
fi
