Otros

    1. Donde debería ser copiado el script para que se pueda ejecutar como cualquier comando del sistema (sin hacer referencia al directorio en el que está), como por ejemplo, ls.
    2. Imprimir el nombre del usuario con el identificador más alto (identificadores almacenados en el fichero /etc/passwd el tercer campo).
    3. Imprimir el nombre de los usuarios cuyo identificador e identificador de grupo sean distintos (en el fichero /etc/passwd, el tercer y cuarto campo).
    4. Mostrar los usuarios con identificador mayor que 100.
    5. Contar las líneas vacías en un fichero.
    6. Contar líneas que sólo contengan espacios o tabuladores.
    7. Eliminar de un fichero las líneas vacías o que sólo tengan espacios y/o tabuladores.
    8. Exportar el contenido del fichero /etc/passwd a un fichero html. Los datos deberán aparecer en formato tabla: a) Una fila por cada usuario b) Una columna por cada usuario
    9. Buscar en el fichero /etc/shadow aquellos usuarios que tengan contraseña establecida.
    10. Dada la ejecución de un determinado programa, filtrar las líneas de la salida estandard que continen un campo de fecha con un determinado valor. P.e, procesar las lineas de ejecutar el comando last -F cuya fecha logging es posterior a una fecha dada
