#!/bin/usr/sh

echo "hola" 2> 3-errores.txt 1> 3-output.txt
