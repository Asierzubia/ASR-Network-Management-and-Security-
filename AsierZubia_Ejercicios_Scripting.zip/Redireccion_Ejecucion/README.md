Estructura de un script - Redirección - Ejecución

    1. Programar un script que muestre el nombre del script.
    2. Programar un script que obtenga un texto (cualquiera) por la salida estándar y otro por la salida estándar de errores.
    3. Modificar el script del punto anterior para que desde el interior del propio script redirija la salida estándar al fichero nombre-del-script-output.txt y la de errores a nombre-del-script-errors.txt.
