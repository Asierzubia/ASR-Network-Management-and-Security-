#!/bin/usr/sh

echo "hola" > prueba.txt 1> salida.txt 
echo "hola" > prueba_2.txt 2> errores.txt
