Wildcarding y expresiones regulares

    1. script que dado una lista de referencias a ficheros (como argumentos) muestra en la salida estandar:
        a. la ruta (directorio) de cada referencia
        b. El nombre de cada fichero sin ruta
        c. La extensón de cada uno de los ficheros
        d. El nombre de cada fichero sin ruta ni extensión

    2. (Avanzado) Programa un script que muestre cuántas extensiones diferentes hay en un directorio, junto con el número de ocurrencias de cada una. Ejemplo:

        txt => 4

        pdf => 2

        …
