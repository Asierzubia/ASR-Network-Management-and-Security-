#!/bin/sh

suma_total=$(echo 1 + 2 + 2 | bc -l)
echo $suma_total
