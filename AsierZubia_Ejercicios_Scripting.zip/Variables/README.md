Variables

    1. Programa un script que calcula y muestra la suma de tres números que recibe como parámetro.
    2. Como el anterior, pero en lugar de recibir los números como parámetros, los recibe a través del teclado.
